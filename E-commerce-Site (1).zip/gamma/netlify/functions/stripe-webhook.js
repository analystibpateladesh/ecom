// This is a Netlify serverless function that handles Stripe webhook events
const stripe = require('stripe')('sk_test_51MrQXlSF2sHVRn44egjqy2FHLMR6ui7I41RCkbm54FLWE9G4MGAEO7N4OFe5WHRaiQm96KsX90bwXgY90TUTmr9l00Wgi7iMcy');

exports.handler = async (event) => {
  try {
    console.log('Webhook handler called');

    // Only allow POST requests
    if (event.httpMethod !== 'POST') {
      return { statusCode: 405, body: 'Method Not Allowed' };
    }

    // Get the webhook secret for signature verification
    const webhookSecret = null; // for testing, just parse the event

    // Verify the webhook signature
    let stripeEvent;
    if (webhookSecret) {
      const signature = event.headers['stripe-signature'];
      try {
        stripeEvent = stripe.webhooks.constructEvent(
          event.body,
          signature,
          webhookSecret
        );
      } catch (err) {
        console.log(`⚠️ Webhook signature verification failed:`, err.message);
        return {
          statusCode: 400,
          body: `Webhook Error: ${err.message}`
        };
      }
    } else {
      // If you don't have a webhook secret, just parse the event
      stripeEvent = JSON.parse(event.body);
    }

    console.log(`Webhook event type: ${stripeEvent.type}`);

    // Handle specific events
    switch (stripeEvent.type) {
      case 'checkout.session.completed':
        const session = stripeEvent.data.object;
        // Here, you would typically:
        // 1. Fulfill the order (e.g., email confirmation, update database)
        // 2. If you have async fulfillment, set a flag in your database
        console.log(`🔔 Payment succeeded! Session ID: ${session.id}`);
        break;

      case 'payment_intent.succeeded':
        const paymentIntent = stripeEvent.data.object;
        console.log(`🔔 PaymentIntent success! Amount: ${paymentIntent.amount}`);
        break;

      case 'payment_intent.payment_failed':
        const failedPayment = stripeEvent.data.object;
        const error = failedPayment.last_payment_error?.message || 'Unknown failure';
        console.log(`❌ Payment failed: ${error}`);
        break;

      default:
        // Unexpected event type
        console.log(`🤷‍♀️ Unhandled event type: ${stripeEvent.type}`);
    }

    // Return a response to acknowledge receipt of the event
    return {
      statusCode: 200,
      body: JSON.stringify({ received: true })
    };
  } catch (error) {
    console.error('Webhook error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message })
    };
  }
};
