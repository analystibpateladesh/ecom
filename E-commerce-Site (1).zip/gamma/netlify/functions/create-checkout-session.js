// This is a Netlify serverless function that creates a Stripe checkout session
const stripe = require('stripe')('sk_test_51MrQXlSF2sHVRn44egjqy2FHLMR6ui7I41RCkbm54FLWE9G4MGAEO7N4OFe5WHRaiQm96KsX90bwXgY90TUTmr9l00Wgi7iMcy');

exports.handler = async (event) => {
  try {
    console.log('Checkout session function called');

    // Only allow POST requests
    if (event.httpMethod !== 'POST') {
      return { statusCode: 405, body: 'Method Not Allowed' };
    }

    // Parse the request body
    const data = JSON.parse(event.body);
    const { items, success_url, cancel_url } = data;

    console.log('Received items:', JSON.stringify(items));
    console.log('Success URL:', success_url);
    console.log('Cancel URL:', cancel_url);

    // Validate input (basic validation)
    if (!items || !items.length || !success_url || !cancel_url) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Missing required parameters' })
      };
    }

    // Format line items for Stripe
    const line_items = items.map(item => {
      const unitAmount = Math.round(parseFloat(item.price.replace(/[^\d.]/g, '')) * 100); // Convert to cents
      console.log(`Item: ${item.name}, Price: ${item.price}, Unit Amount: ${unitAmount}`);
      return {
        price_data: {
          currency: 'usd',
          product_data: {
            name: item.name,
            images: [item.img],
          },
          unit_amount: unitAmount,
        },
        quantity: item.qty,
      };
    });

    // Create a checkout session
    console.log('Creating Stripe checkout session');
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items,
      mode: 'payment',
      success_url: `${success_url}?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: cancel_url,
    });

    console.log('Checkout session created:', session.id);

    // Return the session ID
    return {
      statusCode: 200,
      body: JSON.stringify({ id: session.id, url: session.url })
    };
  } catch (error) {
    console.error('Error creating checkout session:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message })
    };
  }
};
