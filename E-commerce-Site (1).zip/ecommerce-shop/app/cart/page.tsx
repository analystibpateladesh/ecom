"use client";
import { useCart } from "../cart-context";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { toast } from "components/ui/sonner"; // Updated import path for toast

export default function CartPage() {
  const { cart, removeFromCart, clearCart } = useCart();
  const [checkout, setCheckout] = useState(false);
  const [error, setError] = useState("");
  const router = useRouter();

  const handleCheckout = () => {
    clearCart();
    toast.success("Checkout successful! Thank you for your purchase.");
  };

  return (
    <main className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto">
        <h1 className="text-3xl font-bold mb-8 text-center">Shopping Cart</h1>
        {cart.length === 0 ? (
          <div className="bg-white rounded p-6 shadow text-center text-gray-500">
            Your cart is currently empty.
          </div>
        ) : (
          <div className="bg-white rounded p-6 shadow">
            <ul>
              {cart.map((item) => (
                <li key={item.id} className="flex items-center justify-between border-b py-4">
                  <div className="flex items-center gap-4">
                    <img src={item.image} alt={item.name} className="w-16 h-16 object-cover rounded" />
                    <div>
                      <div className="font-semibold">{item.name}</div>
                      <div className="text-blue-600 font-bold">${item.price.toFixed(2)}</div>
                    </div>
                  </div>
                  <button className="text-red-600 hover:underline" onClick={() => removeFromCart(item.id)}>
                    Remove
                  </button>
                </li>
              ))}
            </ul>
            <div className="flex flex-row gap-4 mt-6">
              <button
                className="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded w-full text-lg"
                onClick={() => router.push("/checkout")}
              >
                Proceed to Checkout
              </button>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}
