"use client";
import { useEffect, useState } from "react";

export default function OrderConfirmation() {
  const [order, setOrder] = useState<any>(null);

  useEffect(() => {
    if (typeof window !== "undefined") {
      const item = window.sessionStorage.getItem("order_confirmation");
      if (item) setOrder(JSON.parse(item));
    }
  }, []);

  if (!order) {
    return (
      <main className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto max-w-md">
          <h1 className="text-3xl font-bold mb-8 text-center text-red-600">Order Not Found</h1>
          <div className="bg-white rounded p-6 shadow text-center text-gray-700">
            Sorry, we couldn't find your order details.
          </div>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto max-w-md">
        <h1 className="text-3xl font-bold mb-8 text-center text-green-700">Thank you for your order!</h1>
        <div className="bg-green-100 rounded p-6 shadow text-green-900 mb-6">
          <div className="mb-2 font-semibold">Order for: {order.name}</div>
          <div className="mb-2">Confirmation sent to: {order.email}</div>
          <div className="mb-2">Shipping address: <span className="font-mono">{order.address}</span></div>
        </div>
        <div className="bg-white rounded p-4 shadow">
          <h2 className="text-lg font-semibold mb-3">Purchased Items:</h2>
          <ul>
            {order.items?.map((item: any, idx: number) => (
              <li key={item.id || idx} className="flex justify-between border-b py-2">
                <span>{item.name}</span>
                <span className="text-blue-700 font-bold">${item.price.toFixed(2)}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </main>
  );
}
