import "app/globals.css";
import ClientBody from "app/ClientBody";
import Navbar from "app/Navbar";
import { CartProvider } from "app/cart-context";
import { Toaster } from "components/ui/sonner";
// ... the rest of the code ...
