"use client";

import { useCart } from "app/cart-context";
import type { Product } from "app/cart-context";

export default function Home() {
  const { addToCart } = useCart();
  const products = [
    {
      id: 1,
      name: "Classic White Tee",
      price: 19.99,
      image: "https://images.unsplash.com/photo-1512436991641-6745cdb1723f",
      description: "A timeless white T-shirt for everyday wear.",
    },
    {
      id: 2,
      name: "Blue Denim Jacket",
      price: 49.99,
      image: "https://images.unsplash.com/photo-1503342217505-b0a15ec3261c",
      description: "Trendy and durable denim jacket for comfort and style.",
    },
    {
      id: 3,
      name: "Running Sneakers",
      price: 59.99,
      image: "https://images.unsplash.com/photo-1519864600265-abb23847ef2c",
      description: "Lightweight and comfy sneakers for daily runs.",
    },
  ];

  const handleAddToCart = (product: Product) => {
    addToCart(product);
    alert(`${product.name} has been added to your cart!`);
  };

  return (
    <main className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto">
        <h1 className="text-3xl font-bold mb-8 text-center">Products</h1>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {products.map((product) => (
            <div
              key={product.id}
              className="bg-white rounded-lg overflow-hidden shadow hover:shadow-lg transition p-4 flex flex-col items-center"
            >
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-48 object-cover mb-4 rounded"
              />
              <h2 className="text-lg font-semibold mb-2">{product.name}</h2>
              <p className="text-gray-700 mb-2">{product.description}</p>
              <span className="font-bold text-blue-600 mb-4">${product.price.toFixed(2)}</span>
              <button
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded mt-2 transition"
                onClick={() => handleAddToCart(product)}
              >
                Add to Cart
              </button>
            </div>
          ))}
        </div>
      </div>
    </main>
  );
}
