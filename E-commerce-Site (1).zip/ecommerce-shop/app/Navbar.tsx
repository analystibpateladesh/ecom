"use client";
import Link from "next/link";
import { useCart } from "./cart-context";

function CartBadge() {
  const { cart } = useCart();
  if (cart.length === 0) return null;
  return (
    <span className="ml-1 px-2 py-0.5 text-xs bg-blue-600 text-white rounded-full absolute -right-4 -top-2">
      {cart.length}
    </span>
  );
}

export default function Navbar() {
  return (
    <nav className="bg-white shadow px-6 py-4">
      <div className="container mx-auto flex items-center justify-between">
        <Link href="/" className="text-xl font-bold text-blue-600">Shop</Link>
        <div className="flex items-center gap-6">
          <Link href="/">Products</Link>
          <Link href="/cart" className="relative">
            Cart
            <CartBadge />
          </Link>
        </div>
      </div>
    </nav>
  );
}
