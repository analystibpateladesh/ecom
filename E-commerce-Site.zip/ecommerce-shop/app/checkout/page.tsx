"use client";
import { useCart } from "../cart-context";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function CheckoutPage() {
  const { cart, clearCart } = useCart();
  const [submitted, setSubmitted] = useState(false);
  const router = useRouter();

  const total = cart.reduce((sum, item) => sum + item.price, 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    clearCart();
    setSubmitted(true);
  };

  if (cart.length === 0 && !submitted) {
    // If someone visits checkout with empty cart, go home
    if (typeof window !== "undefined") router.replace("/");
    return null;
  }

  if (submitted) {
    return (
      <div className="checkout-page max-w-xl mx-auto p-8 mt-8 bg-white rounded shadow text-center">
        <h1 className="text-3xl font-bold mb-4">Thank You!</h1>
        <p className="mb-8 text-green-700">Your order has been placed and your cart is now empty.</p>
      </div>
    );
  }

  return (
    <div className="checkout-page max-w-xl mx-auto p-8 mt-8 bg-white rounded shadow">
      <h1 className="text-3xl font-bold mb-4">Checkout</h1>
      <h2 className="text-xl font-semibold mb-3">Order Summary</h2>
      <div className="mb-6">
        <ul>
          {cart.map((item) => (
            <li key={item.id} className="border-b py-4 flex justify-between items-center">
              <span>{item.name}</span>
              <span className="text-blue-700 font-bold">${item.price.toFixed(2)}</span>
            </li>
          ))}
        </ul>
        <div className="font-bold flex justify-between items-center mt-4">
          <span>Total:</span> <span>${total.toFixed(2)}</span>
        </div>
      </div>
      <form className="checkout-form space-y-4" onSubmit={handleSubmit}>
        <div className="form-group">
          <label className="block mb-1">Card Number</label>
          <input className="w-full border p-2 rounded" placeholder="4242 4242 4242 4242" required />
        </div>
        {/* Add more fake form fields here if you want */}
        <button className="bg-green-600 hover:bg-green-700 text-white py-2 px-8 rounded w-full text-lg" type="submit">
          Complete Purchase
        </button>
      </form>
    </div>
  );
}
